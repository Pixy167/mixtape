/* Isi halaman. Edit langsung di sini, atau pakai tools/editor/index.html lalu timpa file ini dengan hasil ekspornya.
   Path file (audio, video, foto, buket) relatif terhadap folder proyek ini. */
window.SITE = {
  "to": "fal",
  "from": "aca",
  "title": "Songs for you",
  "note": {
    "label": "Liner note",
    "paragraphs": [
      "sayang.. aku bukanlah penyair ataupun penulis hebat. Aku hanya gadis biasa yang menyukai sastra dan berusaha untuk mendefinisikan ketampananmu semampuku.\nRasanya aku ingin memberi tahu seisi dunia, bahwa ada satu laki-laki yang begitu indah dirinya, sampai kertas manapun takkan pernah sanggup menampung seluruh pesonanya.\nterimakasih karna sudah selalu memanjakan mata dan jiwaku sayang..\nmeskipun pandanganku rabun menggelut, kamu adalah satu satunya yang jelas kulihat kehadiran dan pesonanya.",
      "terimakasih karna selalu menjadi penghantar bahagia untukku bahkan disaat semesta sedang tidak berpihak padamu, disaat dunia sedang menghajarmu habis habisan, disaat kamu sedang berada di titik paling melelahkan dalam hidupmu.\nsemoga semua sakitmu dibalas keindahan oleh sang Pencipta, semoga selalu tumbuh bunga di sela retak hatimu.",
      "aku tidak tau akan sampai kapan semesta mengizinkan kita bersama, tapi aku harap, semesta mengizinkan kita sedikit lebih lama lagi, lagi, dan lagi..\nkarna nyatanya, aku tak pernah rela jika kita akan berakhir, dan dalam perjalanan panjang semesta; di antara daun daun yang berguguran dan binatang yang penuh warna, aku tak lebih hanya belulang, daging, dan sedikit glukosa, yang berharap kau rela memfosil bersama.",
      "terimakasih karna telah menghilangkan benciku pada versi paling buruk yang aku miliki, kau mencintaiku dengan cara yang membuatku belajar mencintai bagian-bagian dari diriku yang dulu kubenci.",
      "izinkan aku untuk belajar mengenal semua versi dalam dirimu dengan lebih baik.. karna nyatanya, aku masih sering meraba dalam buta perihal memahami perasaan manusia lain, bantu aku sayang.",
      "duduklah, sayang..\nbiarku dekap cacatmu,\nyang mungkin cela di matamu, namun karya indah bagiku.\nsenyumlah, sayang.\nbiarku kenang manismu\ndi antara kertas dan tintaku.\nbiarkan 'ku mencintaimu, dengan penaku yang macet,\ndengan kertas ronyok di kantong jaket, dengan tanganku yang gemetar hebat.\naku tak ingin hanya menggambar lebihmu,\nsebab aku ingin mengenang dirimu seutuhnya.",
      "bawalah seluruh lelahmu kemari, sayang. agar kupeluk erat setiap retak yang membuatmu terjaga semalaman ini.",
      "“Tuhan menyayangimu dengan seribu cara, aku salah satunya. “",
      "andai kau bisa meminjam mataku, kau akan tau betapa indahnya kau dimataku..\nandai kau bisa meminjam hatiku, kau akan tau betapa besar perasaanku padamu..\naku memberikan seluruh yang aku punya, agar saat waktuku telah habis direnggut semesta, tak ada rasa sesalku karna tidak memberikan seluruhnya terhadapmu.",
      "“Jika saja namamu terlalu sering kutulis, atau jika saja ceritaku terlalu penuh tentangmu. Mungkin karena kau seperti senja; seperti kopi pagi, juga seperti lagu favorit yang tak pernah bosan kuputar berulang kali.\nNamun semua keindahanmu hanya bisa\nkupandang dari jauh. Alih-alih mengeluh, aku senang menatap keindahan yang amat pesona itu, binar di matamu, lembut senyummu, serta seluruh tentangmu.\nSebut aku gila, sebab mencintai raga seindah dirimu tak membutuhkan logika.\nBagaimana tidak? Tiap malam kau membuatku bergelut dengan pikiranku, memikirkan hal indah apa lagi yang sepadan denganmu. “",
      "meski selalu dituding makar, aku ingin selalu berlindung di dadamu yang hangat, dan bibirmu yang liberal dari ego kelakar ingin memakzulkan hati dari kepemimpinannya sendiri.",
      "kau boleh menjadi laki-laki paling tangguh di keluargamu, kau boleh berdiri paling tegar menghadapi dunia. tapi saat kau ada dalam dekapku.. kau tak perlu berpura-pura kuat. kau boleh jadi dirimu yang paling rapuh, paling manja dan biarkan aku menjadi rumah yang selalu menjadi arah pulang dan tujuanmu, kapan pun dan dalam keadaan apapun.",
      "Jika Tuhan adalah sebaik baiknya seniman, maka kamu adalah sebaik baiknya mahakarya.",
      "aku mencintaimu dengan seluruh jiwa yang kumiliki, kenanglah aku jika nanti aku sudah tak bisa membersamaimu lagi.",
      "from aca to fal"
    ]
  },
  "letter": {
    "label": "Letter",
    "title": "A letter for you",
    "subtitle": "A small soundtrack for a moment worth keeping.",
    "from": "From aca"
  },
  "voice": {
    "title": "A note for you",
    "hint": "tap to listen",
    "src": "media/note.m4a",
    "duration": 21
  },
  "tracks": [
    {
      "id": "monokrom",
      "title": "Monokrom",
      "artist": "TULUS",
      "audio": "media/monokrom.mp3",
      "video": "media/monokrom.mp4"
    },
    {
      "id": "kekal",
      "title": "Kekal",
      "artist": "Nadin Amizah",
      "audio": "media/kekal.mp3",
      "video": "media/kekal.mp4"
    }
  ],
  "polaroidsTitle": "Polaroids",
  "photos": [
    {
      "id": "p1",
      "src": "assets/photos/photo1.jpg",
      "caption": "aca & fal",
      "rotate": -3,
      "focus": 50
    },
    {
      "id": "p2",
      "src": "assets/photos/photo2.jpg",
      "caption": "aca & fal",
      "rotate": 2.5,
      "focus": 50
    }
  ],
  "bouquetTitle": "Your bouquet",
  "bouquetSub": "From the sender",
  "bouquets": [
    {
      "id": "b1",
      "src": "assets/bq_water.webp"
    },
    {
      "id": "b2",
      "src": "assets/bouquet2.webp"
    },
    {
      "id": "b3",
      "src": "assets/bq_wild.webp"
    }
  ],
  "finishLabel": "Finish mixtape",
  "help": "Tap the envelope to open it, press play on a song, and tap the heart for more."
};
