'use strict';
/* Songs for you — frontend saja (HTML + CSS + JavaScript murni), siap di-deploy ke Vercel / hosting statis apa pun.
   Semua isi (nama, catatan, lagu, foto, buket, voice note) dibaca dari content/site.js (window.SITE).
   Ubah isi lewat tools/editor atau langsung di content/site.js — tidak perlu mengubah kode ini. */
const $=s=>document.querySelector(s),B=document.body;
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const BLANK='data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';   // poster transparan: cegah poster bawaan WebView Android (kotak abu-abu + ikon play)
const U=p=>window.__U?window.__U(p):p;   // build satu-file (tools/make-single.py) mengganti ini supaya aset ikut ter-embed
const mmss=s=>(s/60|0)+':'+String(s%60|0).padStart(2,'0');

// ---- isi halaman dari data (aman: pakai textContent, bukan innerHTML) ----
function render(S){
  const set=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t==null?'':t};
  document.title=S.title||'Songs for you';
  set('b-eb','For '+S.to+' · From '+S.from);set('b-title',S.title);
  set('b-nl',S.note.label);$('#b-note').replaceChildren(...S.note.paragraphs.map(t=>{const p=document.createElement('p');p.textContent=t;return p}));
  $('.nc').classList.toggle('long',S.note.paragraphs.join('').length>700);   // surat panjang → kolom catatan selebar kartu
  set('b-lk',S.letter.label);set('b-lt',S.letter.title);set('b-ls',S.letter.subtitle);set('b-lf',S.letter.from);
  set('b-vt',S.voice.title);set('b-vh',S.voice.hint);set('tm',mmss(S.voice.duration||15));$('.vn').style.display=S.voice.src?'':'none';
  set('fin',S.finishLabel);set('hp',S.help);
  // buket
  set('b-bt',S.bouquetTitle);set('b-bs',S.bouquetSub);const bq=$('#b-bq'),bs=S.bouquets||[],n=bs.length;bq.style.display=n?'':'none';
  const pre={1:[[50,150,0,1]],2:[[33,140,-5,1],[68,156,3,2]],3:[[22,122,-6,1],[50,156,0,2],[79,118,6,1]]};
  const pos=pre[n]||bs.map((_,i)=>[(i+.5)/n*100,Math.max(90,150-8*(n-3)),(i%2?1:-1)*5,i===n>>1?2:1]);
  bs.forEach((b,i)=>{const im=new Image();im.alt='';im.src=U(b.src);im.style.cssText='left:'+pos[i][0]+'%;height:'+pos[i][1]+'px;--r:'+pos[i][2]+'deg;z-index:'+pos[i][3];bq.append(im)});
  // polaroid
  set('b-plt',S.polaroidsTitle);const pg=$('#b-pg'),ps=S.photos||[];$('#b-pls').style.display=ps.length?'':'none';
  ps.forEach((p,i)=>{const b=document.createElement('button');b.className='pl';b.style.setProperty('--r',(p.rotate||0)+'deg');b.setAttribute('aria-label','Photo '+(i+1)+(p.caption?': '+p.caption:''));
    b.innerHTML='<span class="pw"><span class="win"><img class="ph" alt=""></span><img class="fr" alt=""></span><span class="cap"></span>';
    const im=b.querySelector('.ph');im.src=p.src.startsWith('data:')?p.src:U(p.src);b.querySelector('.fr').src=U('assets/polaroid-frame.webp');im.style.objectPosition='50% '+(p.focus==null?40:p.focus)+'%';b.querySelector('.cap').textContent=p.caption||'';pg.append(b)});
}

// ?preview → pakai draf dari tools/editor (localStorage); selain itu pakai content/site.js
const SRC=(()=>{try{if(/[?&]preview\b/.test(location.search)){const d=JSON.parse(localStorage.getItem('sfy-draft')||'null');if(d)return d}}catch(e){}return window.SITE})();
try{if(!SRC)throw new Error('content/site.js tidak ditemukan');init(SRC)}
catch(e){console.error(e);const t=$('#tap');if(t)t.textContent='Can’t load the content (content/site.js).'}

function init(SITE){
render(SITE);
// flowers: bunga orisinal tersebar acak tapi rata (Poisson-disc), "dilempar" dari amplop lalu pop di tempatnya, secukupnya (ga penuh)
const burst=()=>{
  const SPR=[...document.querySelectorAll('#sp img')],cv=$('#bc'),x=cv.getContext('2d'),dp=Math.min(devicePixelRatio||1,2),vw=innerWidth,vh=innerHeight;
  cv.width=vw*dp;cv.height=vh*dp;
  const sc=Math.max(vw/1016,vh/576),cx=vw/2,cy=vh/2-36*sc,D=Math.max(120,Math.min(250,Math.sqrt(vw*vh)*.26)),
    N=Math.min(70,Math.round(vw*vh*1.25/(.67*D*D))),rm=.74*D,P=[];
  for(let n=0;n<4000&&P.length<N;n++){const px=(Math.random()*1.08-.04)*vw,py=(Math.random()*1.08-.04)*vh;
    if(P.every(q=>Math.hypot(q[0]-px,q[1]-py)>=rm))P.push([px,py])}
  const ord=SPR.map((_,i)=>i).sort(()=>Math.random()-.5),Rm=Math.hypot(vw,vh)/2,
    F=P.map((q,i)=>({tx:q[0],ty:q[1],s:D*(.86+.28*Math.random()),rot:Math.random()*6.283,k:ord[i%ord.length],d:.05+.85*Math.pow(Math.hypot(q[0]-cx,q[1]-cy)/Rm,.85)+Math.random()*.08}));
  F.sort((a,b)=>a.ty-b.ty);
  const t0=performance.now(),eo=p=>1-Math.pow(1-p,3),eb=p=>1+2.4*Math.pow(p-1,3)+1.4*Math.pow(p-1,2);
  const step=now=>{const t=(now-t0)/1e3;x.setTransform(dp,0,0,dp,0,0);x.clearRect(0,0,vw,vh);
    for(const f of F){let p=(t-f.d)/1.05;if(p<=0)continue;p=Math.min(p,1);
      const m=eo(p),w=f.s*eb(p),im=SPR[f.k];if(!im||!im.naturalWidth)continue;const h=w*im.naturalHeight/im.naturalWidth;
      x.globalAlpha=Math.min(1,p*3);x.save();x.translate(cx+(f.tx-cx)*m,cy+(f.ty-cy)*m);x.rotate(f.rot+(1-m)*1.2);x.drawImage(im,-w/2,-h/2,w,h);x.restore()}
    if(t<3)requestAnimationFrame(step)};
  requestAnimationFrame(step)};

// open
const open=()=>{if(B.dataset.s)return;B.dataset.s='bloom';
  // video klip amplop dibuat saat dibutuhkan (bukan di HTML) supaya tidak ada elemen <video>/poster yang tampak di layar awal
  const v=document.createElement('video'),hide=()=>$('#env').style.visibility='hidden',nov=()=>{hide();B.classList.add('nov')};
  v.id='bv';v.muted=true;v.setAttribute('playsinline','');v.setAttribute('webkit-playsinline','');v.preload='auto';v.poster=BLANK;$('#bloom').prepend(v);
  v.src=U('media/bloom.mp4');v.onplaying=()=>{v.classList.add('on');requestAnimationFrame(hide)};v.onerror=nov;
  const p=v.play();if(p)p.catch(nov);setTimeout(burst,520);setTimeout(()=>B.dataset.s='page',4800)};
$('#env').onclick=open;$('#env').onkeydown=e=>{if(e.key==='Enter'||e.key===' ')open()};
// help
$('#help').onclick=()=>$('#hp').classList.toggle('o');
// tracks
const T=(SITE.tracks||[]).map(t=>({id:t.id,n:t.title,a:t.artist,mp3:t.audio,mp4:t.video||''}));
const ico='<svg class="pp" viewBox="0 0 10 10"><path d="M1 0l9 5-9 5z"/></svg><svg class="ps" viewBox="0 0 10 10"><path d="M1 0h3v10H1zM6 0h3v10H6z"/></svg>';
$('#tl').innerHTML=T.map((t,i)=>`<li><span class="n">0${i+1}</span><span class="t"><b>${esc(t.n)}</b><small>${esc(t.a)}</small></span><button class="pb" aria-label="Play ${esc(t.n)}">${ico}</button></li>`).join('');
const li=[...document.querySelectorAll('#tl li')],E=$('#E');
let cur=-1,tm;const M=[];
const stat=t=>$('#st').textContent=t,mark=()=>li.forEach((l,i)=>l.classList.toggle('on',i===cur));
const fmt=s=>isFinite(s)?(s/60|0)+':'+String(s%60|0).padStart(2,'0'):'0:00';
const full=v=>{const c=v.closest('.pc'),f=c&&(c.requestFullscreen||c.webkitRequestFullscreen);f?f.call(c):(v.requestFullscreen||v.webkitRequestFullscreen||v.webkitEnterFullscreen).call(v)};
const fsx=()=>{const e=document.fullscreenElement||document.webkitFullscreenElement;document.querySelectorAll('.pc').forEach(p=>p.classList.toggle('fsm',p===e))};
document.addEventListener('fullscreenchange',fsx);document.addEventListener('webkitfullscreenchange',fsx);
function panel(o){$('#panel').classList.toggle('o',o);$('#heart').setAttribute('aria-expanded',o);if(o)$('#more').classList.add('h')}
function mk(i){
  const t=T[i],c=document.createElement('div');c.className='pc';
  c.innerHTML=`<button class="x" aria-label="Close"><svg viewBox="0 0 12 12"><path d="M2 2l8 8M10 2l-8 8" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><video muted playsinline preload="metadata" poster="${BLANK}" aria-label="${esc(t.n)}"></video><div class="cb"><span class="tc">0:00</span><input class="sk" type="range" min="0" max="1000" value="0" aria-label="Seek"><span class="td">0:00</span><button class="fs" aria-label="Fullscreen"><svg viewBox="0 0 12 12"><path d="M1 4V1h3M8 1h3v3M11 8v3H8M4 11H1V8" fill="none" stroke="currentColor" stroke-width="1.4"/></svg></button></div>`;
  const v=c.querySelector('video'),sk=c.querySelector('.sk'),tc=c.querySelector('.tc'),td=c.querySelector('.td'),a=new Audio(U(t.mp3));
  v.muted=true;a.preload='auto';
  if(t.mp4)setTimeout(()=>{v.src=U(t.mp4);if(!a.paused){v.currentTime=a.currentTime;v.play().catch(()=>{})}},80);else c.classList.add('novid');
  a.onerror=()=>stat('Can’t load '+t.mp3);
  a.onloadedmetadata=()=>td.textContent=fmt(a.duration);
  a.ontimeupdate=()=>{sk.value=a.duration?a.currentTime/a.duration*1000:0;tc.textContent=fmt(a.currentTime);if(!a.paused&&Math.abs(v.currentTime-a.currentTime)>.35)v.currentTime=a.currentTime};
  a.onended=()=>{v.pause();if(cur===i){cur=-1;mark();stat('')}};
  sk.oninput=()=>{if(a.duration){a.currentTime=a.duration*sk.value/1000;v.currentTime=a.currentTime}};
  v.onpause=()=>{if(cur===i&&!a.paused)a.pause()};
  v.onplay=()=>{if(cur===i&&a.paused)a.play()};
  c.querySelector('.fs').onclick=()=>full(v);
  c.querySelector('.x').onclick=()=>{const fe=document.fullscreenElement||document.webkitFullscreenElement;if(fe===c){(document.exitFullscreen||document.webkitExitFullscreen).call(document);return}
    stop(i);if(cur===i){cur=-1;mark();stat('');clearTimeout(tm)}
    a.onerror=null;a.removeAttribute('src');a.load();v.removeAttribute('src');v.load();c.remove();delete M[i];if(i===T.length-1)$('#fin').hidden=true};
  i?E.append(c):E.prepend(c);
  return M[i]={a,v};
}
function stop(i){const m=M[i];if(m){m.a.pause();m.v.pause()}}
function play(i){
  if(cur===i){stop(i);cur=-1;mark();stat('');clearTimeout(tm);return}
  if(cur>-1)stop(cur);
  cur=i;mark();clearTimeout(tm);stat('Starting: '+T[i].n);
  tm=setTimeout(()=>{if(!(M[i]&&M[i].a.error))stat('Playing: '+T[i].n)},1200);
  panel(true);
  const m=M[i]||mk(i);m.a.play().catch(()=>{});m.v.play().catch(()=>{});
  if(i===T.length-1)$('#fin').hidden=false;
  setTimeout(()=>E.scrollIntoView({behavior:'smooth',block:'end'}),300);
}
li.forEach((l,i)=>l.querySelector('.pb').onclick=()=>play(i));
$('#heart').onclick=()=>panel(!$('#panel').classList.contains('o'));
$('#px').onclick=()=>panel(false);
addEventListener('keydown',e=>{if(e.key!=='Escape')return;if(!$('#lb').hidden)$('#lb').hidden=true;else if($('#panel').classList.contains('o'))panel(false)});
$('#fin').onclick=()=>{const m=M[T.length-1]||M[0];if(m)full(m.v)};
// foto polaroid: tap untuk memperbesar
const LB=$('#lb'),LBP=LB.querySelector('.lbp');
document.querySelectorAll('.pl').forEach(p=>p.onclick=()=>{LBP.replaceChildren(p.querySelector('.pw').cloneNode(true),p.querySelector('.cap').cloneNode(true));LB.hidden=false});
LB.onclick=e=>{if(!e.target.closest('.lbp'))LB.hidden=true};
// fullscreen (seluruh halaman)
const de=document.documentElement,rfs=de.requestFullscreen||de.webkitRequestFullscreen,efs=document.exitFullscreen||document.webkitExitFullscreen,fsel=()=>document.fullscreenElement||document.webkitFullscreenElement;
const fsu=()=>B.classList.toggle('isfs',fsel()===de);
document.addEventListener('fullscreenchange',fsu);document.addEventListener('webkitfullscreenchange',fsu);
$('#fsb').onclick=()=>{
  if(!rfs||!efs){const t=$('#ft');t.classList.add('o');clearTimeout(t.k);t.k=setTimeout(()=>t.classList.remove('o'),3800);return}
  if(fsel())efs.call(document);else{const p=rfs.call(de);p&&p.catch&&p.catch(()=>{})}};
// voice note
const hs=[5,8,12,9,14,7,10,6,9,12,8,5,11,7,9,6,10,8,5,7];
$('#wv').innerHTML=hs.map(v=>`<i style="--h:${v}px"></i>`).join('');
const NOTE_SRC=(SITE.voice&&SITE.voice.src)||'';
let nt=0,au=null;const nd=()=>au&&isFinite(au.duration)?Math.round(au.duration):(SITE.voice&&SITE.voice.duration)||15,nau=()=>{if(!au&&NOTE_SRC){au=new Audio(U(NOTE_SRC));au.onloadedmetadata=()=>$('#tm').textContent=mmss(nd())}return au};
$('#nb').onclick=()=>{
  const b=$('#nb'),bars=[...document.querySelectorAll('#wv i')];nau();
  if(nt){clearInterval(nt);nt=0;b.classList.remove('on');au&&au.pause();return}
  let k=au&&!au.ended?Math.floor(au.currentTime):0;b.classList.add('on');au&&au.play();
  nt=setInterval(()=>{k++;bars.forEach((x,j)=>x.classList.toggle('d',j<k*bars.length/nd()));$('#tm').textContent=mmss(Math.max(0,nd()-k));
    if(k>=nd()){clearInterval(nt);nt=0;b.classList.remove('on')}},1000)};
}
