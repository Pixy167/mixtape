'use strict';
// Tes statis (tanpa dependensi): jalankan dengan `node --test` (Node ≥ 18)
const test = require('node:test'), assert = require('node:assert/strict'), vm = require('vm'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), read = f => fs.readFileSync(path.join(ROOT, f), 'utf8'), exists = f => fs.existsSync(path.join(ROOT, f));
const loadSite = () => { const w = {}; vm.runInNewContext(read('content/site.js'), { window: w }); return w.SITE; };

test('content/site.js valid dan lengkap', () => {
  const s = loadSite();
  for (const k of ['to', 'from', 'title', 'note', 'letter', 'voice', 'tracks', 'photos', 'bouquets', 'finishLabel', 'help']) assert.ok(k in s, 'field hilang: ' + k);
  assert.ok(s.tracks.length >= 1); assert.ok(s.note.paragraphs.length >= 1);
  const ids = s.tracks.map(t => t.id); assert.equal(new Set(ids).size, ids.length, 'id lagu harus unik');
});
test('semua file yang dirujuk ada di folder proyek', () => {
  const txt = ['index.html', 'css/style.css', 'js/app.js', 'content/site.js'].map(read).join('\n');
  const refs = new Set([...txt.matchAll(/(?<![\w/.])((?:assets|media)\/[\w\-./]+\.(?:webp|jpg|jpeg|png|mp3|m4a|mp4|webm))/g)].map(m => m[1]));
  assert.ok(refs.size > 20, 'harus menemukan banyak rujukan: ' + refs.size);
  for (const r of refs) assert.ok(exists(r), 'file hilang: ' + r);
});
test('path relatif saja (aman untuk subfolder / file://) dan tanpa sisa backend', () => {
  for (const f of ['index.html', 'css/style.css', 'js/app.js']) assert.ok(!/["'(]\/(assets|media|css|js|content)\//.test(read(f)), 'path absolut di ' + f);
  const js = read('js/app.js'); assert.ok(!/fetch\(|\/api\/|sendBeacon/.test(js), 'app.js tidak boleh memanggil backend');
  const html = read('index.html'); assert.ok(html.indexOf('content/site.js') > 0 && html.indexOf('content/site.js') < html.indexOf('js/app.js'), 'site.js harus dimuat sebelum app.js');
  assert.match(html, /name="robots" content="noindex/);
});
test('semua id yang dipakai app.js ada di index.html', () => {
  const html = read('index.html'), js = read('js/app.js');
  const ids = new Set([...js.matchAll(/\$\('#([\w-]+)'\)/g)].map(m => m[1]).concat([...js.matchAll(/set\('([\w-]+)'/g)].map(m => m[1])));
  for (const id of ids) assert.ok(html.includes(`id="${id}"`), 'id tidak ada di HTML: ' + id);
});
test('konfigurasi Vercel valid dan tools/tests tidak ikut deploy', () => {
  const v = JSON.parse(read('vercel.json')); assert.ok(Array.isArray(v.headers));
  const ig = read('.vercelignore').split(/\s+/); assert.ok(ig.includes('tools') && ig.includes('tests'));
  assert.ok(!exists('package.json') && !exists('server.js'), 'tidak boleh ada backend / package.json');
});

test('tidak ada file aset/media yang menganggur (semua dirujuk)', () => {
  const txt = ['index.html', 'css/style.css', 'js/app.js', 'content/site.js'].map(read).join('\n'), orphan = [];
  const walk = d => fs.readdirSync(path.join(ROOT, d), { withFileTypes: true }).forEach(e => e.isDirectory() ? walk(d + '/' + e.name) : (txt.includes(d + '/' + e.name) ? 0 : orphan.push(d + '/' + e.name)));
  walk('assets'); walk('media'); assert.deepEqual(orphan, [], 'file tidak terpakai: ' + orphan);
});

test('tidak ada <video> di HTML awal; semua video buatan JS memakai poster transparan', () => {
  assert.ok(!/<video/.test(read('index.html')), 'elemen video di HTML awal memunculkan poster bawaan WebView');
  const js = read('js/app.js'); assert.ok(js.includes('BLANK') && (js.match(/poster/g) || []).length >= 2);
});
