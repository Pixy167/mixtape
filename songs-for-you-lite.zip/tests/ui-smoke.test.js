'use strict';
// Tes asap UI TANPA browser: DOM palsu + alur utama dijalankan (menangkap ReferenceError/TypeError).
// Bukan pengganti uji di browser sungguhan.
const test = require('node:test'), assert = require('node:assert/strict'), vm = require('vm'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), read = f => fs.readFileSync(path.join(ROOT, f), 'utf8');
const SITE = (() => { const w = {}; vm.runInNewContext(read('content/site.js'), { window: w }); return w.SITE; })();

const { makeEnv } = require('./_dom');
const tick = () => new Promise(r => setImmediate(r));

test('app.js: render, escape XSS, buka amplop → putar lagu → voice note → lightbox', async () => {
  const site = JSON.parse(JSON.stringify(SITE)); site.tracks[0].title = '<img src=x onerror=alert(1)>'; site.tracks[0].artist = 'A & B';
  const env = makeEnv(site); vm.runInContext(read('js/app.js'), env.ctx); await tick();
  assert.deepEqual(env.errors, [], 'init tidak boleh error: ' + env.errors.join(' | '));
  const q = s => env.root.querySelector(s);
  assert.equal(env.ctx.document.title, site.title); assert.equal(q('#b-eb').textContent, `For ${site.to} · From ${site.from}`);
  assert.equal(q('#b-note')._k.length, site.note.paragraphs.length); assert.equal(q('#b-pg')._k.length, site.photos.length); assert.equal(q('#b-bq')._k.length, site.bouquets.length);
  const html = q('#tl').innerHTML; assert.ok(html.includes('&lt;img src=x') && !html.includes('<img src=x')); assert.match(html, /A &amp; B/);
  q('#env').onclick(); assert.equal(env.ctx.document.body.dataset.s, 'bloom');
  env.root.querySelectorAll('#tl li')[0].querySelector('.pb').onclick(); await tick();
  assert.ok(env.audios.some(a => a.src === site.tracks[0].audio), 'Audio dibuat dengan path lagu: ' + site.tracks[0].audio);
  q('#nb').onclick(); assert.ok(env.audios.some(a => a.src === site.voice.src), 'voice note memakai path dari site.js');
  env.root.querySelectorAll('.pl')[0].onclick(); assert.equal(q('#lb').hidden, false);
  while (env.timers.length) { const f = env.timers.shift(); try { f(); } catch (e) { assert.fail('timer error: ' + e.message); } }
  assert.deepEqual(env.errors, []);
});
test('app.js: ?preview memakai draf dari editor (localStorage)', async () => {
  const draft = JSON.parse(JSON.stringify(SITE)); draft.title = 'Judul Draf'; draft.to = 'Draf';
  const env = makeEnv(SITE, { location: { search: '?preview' } }); env.store['sfy-draft'] = JSON.stringify(draft);
  vm.runInContext(read('js/app.js'), env.ctx); await tick(); assert.deepEqual(env.errors, []);
  assert.equal(env.ctx.document.title, 'Judul Draf'); assert.equal(env.root.querySelector('#b-eb').textContent, 'For Draf · From ' + draft.from);
});
test('app.js: tanpa SITE → pesan error, tanpa crash', async () => {
  const env = makeEnv(SITE); delete env.ctx.SITE; vm.runInContext(read('js/app.js'), env.ctx); await tick();
  assert.match(env.root.querySelector('#tap').textContent, /Can’t load/);
});
test('app.js: tanpa voice note/buket/foto → bagian disembunyikan', async () => {
  const site = JSON.parse(JSON.stringify(SITE)); site.voice.src = ''; site.bouquets = []; site.photos = []; site.tracks = [{ id: 'x', title: 'Satu', artist: 'Z', audio: 'media/a.mp3', video: '' }];
  const env = makeEnv(site); vm.runInContext(read('js/app.js'), env.ctx); await tick(); assert.deepEqual(env.errors, []);
  const q = s => env.root.querySelector(s); assert.equal(q('.vn').style.display, 'none'); assert.equal(q('#b-bq').style.display, 'none'); assert.equal(q('#b-pls').style.display, 'none');
  env.root.querySelectorAll('#tl li')[0].querySelector('.pb').onclick(); await tick(); assert.deepEqual(env.errors, []);
});
test('editor.js: semua tab terender, draf tersimpan, ekspor site.js valid, id unik', async () => {
  const env = makeEnv(JSON.parse(JSON.stringify(SITE))); vm.runInContext(read('tools/editor/editor.js'), env.ctx); await tick();
  assert.deepEqual(env.errors, []);
  const n = vm.runInContext('PANES.length', env.ctx);
  for (let i = 0; i < n; i++) { vm.runInContext(`tab=${i};show()`, env.ctx); assert.ok(env.root.querySelector('#pane')._k.length > 0, 'tab kosong: ' + i); }
  vm.runInContext('S.to="Baru";S.note.paragraphs.push("  ","paragraf baru");S.tracks.push({id:"",title:"Sweet Scar",artist:"x",audio:"media/x.mp3",video:""});mark()', env.ctx);
  assert.equal(JSON.parse(env.store['sfy-draft']).to, 'Baru', 'draf tersimpan otomatis');
  env.root.querySelector('#save').onclick(); const txt = await env.blobs[env.blobs.length - 1].text();
  assert.match(txt, /^\/\*[\s\S]*\*\/\nwindow\.SITE = \{/); const w = {}; vm.runInNewContext(txt, { window: w });
  assert.equal(w.SITE.to, 'Baru'); assert.ok(!w.SITE.note.paragraphs.includes('') && w.SITE.note.paragraphs.includes('paragraf baru'), 'paragraf kosong dibuang');
  const ids = w.SITE.tracks.map(t => t.id); assert.equal(new Set(ids).size, ids.length, 'id lagu unik: ' + ids);
  vm.runInContext('discard()', env.ctx); assert.equal(env.store['sfy-draft'], undefined); assert.equal(vm.runInContext('S.to', env.ctx), SITE.to);
  assert.deepEqual(env.errors, []);
});
