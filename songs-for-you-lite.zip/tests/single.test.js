'use strict';
// Tes versi satu file (dist/index.html, dibuat oleh `python3 tools/make-single.py`). Dilewati kalau dist belum dibuat.
const test = require('node:test'), assert = require('node:assert/strict'), vm = require('vm'), fs = require('fs'), path = require('path');
const { makeEnv } = require('./_dom');
const ROOT = path.join(__dirname, '..'), DIST = path.join(ROOT, 'dist', 'index.html'), skip = !fs.existsSync(DIST) && 'dist/index.html belum dibuat';
const tick = () => new Promise(r => setImmediate(r));
const load = () => {
  const html = fs.readFileSync(DIST, 'utf8');
  const blocks = Object.fromEntries([...html.matchAll(/<script type="text\/plain" data-media="([^"]+)" data-type="([^"]+)">([A-Za-z0-9+/=]+)<\/script>/g)].map(m => [m[1], { textContent: m[3], dataset: { type: m[2] } }]));
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
  return { html, blocks, scripts };
};

test('single: satu file, tanpa rujukan eksternal, ukuran di bawah batas GitHub web', { skip }, () => {
  const { html, blocks, scripts } = load();
  assert.ok(fs.statSync(DIST).size < 25 * 1048576, 'harus < 25 MB');
  assert.ok(!/(?:src|href)="(?:assets|media|css|js|content)\//.test(html), 'tidak boleh ada rujukan ke file luar');
  assert.equal(scripts.length, 3, 'site.js + helper + app.js'); for (const s of scripts) new vm.Script(s);
  const names = Object.keys(blocks); assert.ok(names.length >= 5, 'blok media: ' + names);
  for (const p of names) assert.ok(Buffer.from(blocks[p].textContent, 'base64').equals(fs.readFileSync(path.join(ROOT, p))), 'isi media berbeda dari file asli: ' + p);
});
test('single: halaman jalan end-to-end — lagu (& voice note bila ada) → blob, foto/buket → data-URI', { skip }, async () => {
  const { blocks, scripts } = load(); const env = makeEnv({ tracks: new Array(2), photos: new Array(4), bouquets: [] }, { atob });
  const doc = env.ctx.document, orig = doc.querySelector;
  doc.querySelector = s => { const m = /^script\[data-media="([^"]+)"\]$/.exec(s); return m ? (blocks[m[1]] || null) : orig(s); };
  for (const s of scripts) vm.runInContext(s, env.ctx); await tick();
  assert.deepEqual(env.errors, [], env.errors.join(' | '));
  const site = env.ctx.SITE, q = s => env.root.querySelector(s);
  for (const im of q('#b-bq')._k) assert.match(im.src, /^data:image\/webp;base64,/, 'buket harus data-URI');
  for (const b of q('#b-pg')._k) { assert.match(b.querySelector('.ph').src, /^data:image\/jpeg;base64,/); assert.match(b.querySelector('.fr').src, /^data:image\/webp;base64,/); }
  const hasNote = !!site.voice.src;   // konten bawaan tanpa voice note; kalau diisi lagi lewat editor, ikut diuji
  q('#env').onclick(); env.root.querySelectorAll('#tl li')[0].querySelector('.pb').onclick(); if (hasNote) q('#nb').onclick(); await tick();
  assert.deepEqual(env.errors, [], env.errors.join(' | '));
  const urls = env.audios.map(a => a.src); assert.ok(urls.length >= (hasNote ? 2 : 1) && urls.every(u => /^blob:/.test(u)), 'Audio harus memakai blob URL: ' + urls);
  const bytes = async i => Buffer.from(await env.blobs[i].arrayBuffer());
  const sweet = fs.readFileSync(path.join(ROOT, site.tracks[0].audio));
  const all = await Promise.all(env.blobs.map((_, i) => bytes(i)));
  assert.ok(all.some(b => b.equals(sweet)), 'blob lagu = file asli');
  if (hasNote) assert.ok(all.some(b => b.equals(fs.readFileSync(path.join(ROOT, site.voice.src)))), 'blob voice note = file asli');
  else assert.ok(!Object.keys(blocks).some(p => p.endsWith('.m4a')), 'tanpa voice note → tidak ada audio .m4a ikut ter-embed');
});

test('single: tap amplop sebelum DOMContentLoaded diantre (tanpa teks Loading…) lalu dijalankan', { skip }, async () => {
  const { scripts } = load(); const env = makeEnv({ tracks: new Array(2), photos: new Array(2), bouquets: [] }, { atob });
  const doc = env.ctx.document, dcl = [], wl = []; doc.readyState = 'loading'; doc.addEventListener = (t, f) => dcl.push([t, f]);
  env.ctx.addEventListener = (t, f, c) => wl.push([t, f, c]); env.ctx.removeEventListener = () => {};
  const tap = env.root.querySelector('#tap'), envEl = env.root.querySelector('#env'); tap.textContent = 'Tap to open'; let clicks = 0; envEl.click = () => clicks++;
  for (const s of scripts) vm.runInContext(s, env.ctx); await tick();
  assert.equal(tap.textContent, 'Tap to open', 'tidak boleh ada tulisan Loading…');
  const hit = wl.find(([t, , c]) => t === 'click' && c === true); assert.ok(hit, 'harus ada pencegat klik (capture)');
  let stopped = 0; hit[1]({ target: { closest: s => (s === '#env' ? {} : null) }, stopPropagation: () => stopped++, preventDefault() {} });
  assert.equal(stopped, 1, 'klik dini dihentikan'); assert.equal(clicks, 0);
  dcl.find(([t]) => t === 'DOMContentLoaded')[1](); assert.equal(clicks, 1, 'klik yang diantre dijalankan setelah siap');
  assert.deepEqual(env.errors, []);
});
