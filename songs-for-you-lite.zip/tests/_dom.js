'use strict';
// DOM palsu untuk tes asap (dipakai ui-smoke.test.js dan single.test.js)
const vm = require('vm');
function makeEnv(site, extra = {}) {
  const counts = { '#tl li': site.tracks.length, '#sp img': 9, '.pl': (site.photos || []).length, '#wv i': 24 };
  const el = (tag = 'div') => {
    const e = { nodeType: 1, tag, _k: [], _a: {}, _l: {}, _q: new Map(), _qa: new Map(), style: { setProperty() {}, removeProperty() {} }, dataset: {}, hidden: false, value: '', textContent: '', innerHTML: '', src: '', className: '',
      paused: true, ended: false, currentTime: 0, duration: NaN, width: 0, height: 0, naturalWidth: 700, naturalHeight: 650, offsetWidth: 100, classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
      append(...k) { e._k.push(...k); }, prepend(...k) { e._k.unshift(...k); }, appendChild(k) { e._k.push(k); return k; }, replaceChildren(...k) { e._k = k; }, remove() {},
      setAttribute(k, v) { e._a[k] = v; }, getAttribute(k) { return e._a[k] ?? null; }, addEventListener(t, f) { (e._l[t] ||= []).push(f); }, removeEventListener() {},
      querySelector(s) { if (!e._q.has(s)) e._q.set(s, el(s)); return e._q.get(s); }, querySelectorAll(s) { if (!e._qa.has(s)) e._qa.set(s, Array.from({ length: counts[s] ?? 1 }, () => el(s))); return e._qa.get(s); },
      closest() { return e; }, cloneNode() { return el('clone'); }, play() { e.paused = false; return Promise.resolve(); }, pause() { e.paused = true; }, load() {}, focus() {}, click() {}, scrollIntoView() {},
      getBoundingClientRect: () => ({ left: 0, top: 0, width: 100, height: 100 }), getContext: () => new Proxy({}, { get: () => () => {}, set: () => true }) };
    return e;
  };
  const root = el('document'), audios = [], errors = [], timers = [], blobs = [], store = {};
  const document = { body: el('body'), documentElement: el('html'), title: '', createElement: el, createTextNode: t => ({ nodeType: 3, data: String(t) }),
    querySelector: s => root.querySelector(s), querySelectorAll: s => root.querySelectorAll(s), getElementById: id => root.querySelector('#' + id), addEventListener() {}, fullscreenElement: null };
  class Audio { constructor(src) { this.src = src; this.paused = true; this.currentTime = 0; this.duration = NaN; audios.push(this); } play() { this.paused = false; return Promise.resolve(); } pause() { this.paused = true; } load() {} }
  class Image { constructor() { return el('img'); } }
  const ctx = { document, Audio, Image, Blob, JSON, Math, Promise, console: { error: (...a) => errors.push(a.join(' ')), log() {} }, SITE: site, location: { search: '' },
    localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = v; }, removeItem: k => { delete store[k]; } },
    URL: { createObjectURL: b => { blobs.push(b); return 'blob:' + blobs.length; } }, navigator: { clipboard: { writeText: async () => {} } }, innerWidth: 390, innerHeight: 844, devicePixelRatio: 3,
    performance: { now: () => 0 }, requestAnimationFrame: () => 1, setTimeout: f => { timers.push(f); return timers.length; }, clearTimeout() {}, setInterval: () => 1, clearInterval() {}, addEventListener() {},
    confirm: () => true, open() {}, ...extra };
  ctx.window = ctx; vm.createContext(ctx);
  return { ctx, root, audios, errors, timers, blobs, store };
}
module.exports = { makeEnv };
