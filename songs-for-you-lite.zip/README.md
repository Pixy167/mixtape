# Songs for you — versi frontend (siap Vercel)

Halaman kado mixtape digital (amplop → bunga mekar → kartu kaset, daftar lagu, catatan, polaroid, buket, voice note).
**100% frontend**: HTML + CSS + JavaScript murni, tanpa server dan tanpa build step. Bisa di-deploy ke Vercel, Netlify, Cloudflare Pages, atau GitHub Pages.

## Kalau GitHub menolak karena kebesaran

GitHub (upload lewat web) hanya menerima **maks. 25 MB per file**, **tidak meng-unzip** file zip, dan dari **HP tidak bisa upload folder**.
Pilih salah satu cara ini:

| Situasi | Cara |
|---|---|
| Dari HP / mau paling gampang | Pakai **`index.html` satu file** (±20 MB, semua gambar & lagu sudah ter-embed). Upload *file itu saja* ke repo GitHub → import ke Vercel. |
| Dari komputer | Ekstrak zip, lalu drag **isi folder** (bukan zipnya) ke halaman *Upload files* GitHub. Semua file < 5 MB. |
| Tanpa GitHub sama sekali | **Netlify Drop** (app.netlify.com/drop): upload zip ini langsung → langsung online. Cloudflare Pages (*Direct Upload*) juga bisa. |

Membuat ulang versi satu file setelah mengubah isi: `python3 tools/make-single.py` → hasilnya `dist/index.html`.

## Struktur

```
index.html          halaman utama
css/style.css       gaya
js/app.js           logika halaman (membaca isi dari content/site.js)
content/site.js     ← SELURUH ISI halaman (nama, catatan, lagu, foto, buket, voice note)
assets/  media/     gambar, audio, video (lagu 128 kbps, video 360p supaya ringan)
tools/editor/       editor offline untuk mengubah isi (tidak ikut deploy)
tools/make-single.py  pembuat versi satu file
tests/              tes otomatis (tidak ikut deploy)
vercel.json         cache & header
```

## Menjalankan di komputer

Klik dua kali `index.html` (Chrome/Edge/Firefox desktop), atau `python3 -m http.server 8000` lalu buka http://localhost:8000.
Dari HP, file manager/ZArchiver **tidak bisa** membuka halaman berfolder — deploy dulu lalu buka link-nya.
(Versi satu file `index.html` bisa dibuka langsung.)

## Mengubah isi

**Editor (tanpa kode):** buka `tools/editor/index.html` → ubah nama, catatan, lagu, foto, buket, voice note → **Unduh site.js** →
timpa `content/site.js` → deploy ulang. **Pratinjau** membuka `index.html?preview` dengan draf dari browser. File baru (lagu/foto)
disalin sendiri ke `media/` atau `assets/photos/` (daftarnya ada di tab **Ekspor**).

**Langsung:** edit `content/site.js` (berkomentar; path file relatif terhadap folder proyek).

## Deploy ke Vercel

1. Taruh file di repo GitHub (lihat tabel di atas).
2. vercel.com → *Add New… → Project* → pilih repo → *Framework Preset*: **Other** → kosongkan Build/Output → **Deploy**.
3. Atau lewat CLI: `npm i -g vercel` lalu `vercel --prod`.

`vercel.json` mengatur cache media dan header `noindex`; halaman juga memakai `<meta name="robots" content="noindex">`.
Siapa pun yang punya link bisa membuka halaman ini (termasuk fotonya) — bagikan hanya ke orang yang dituju.
Lagu, foto, dan gambar bunga milik masing-masing pemiliknya; pastikan kamu berhak memakainya sebelum dipublikasikan.

## Tes

```bash
node --test      # Node 18+, tanpa dependensi (12 tes; tes versi satu file jalan jika dist/ sudah dibuat)
```
Tes UI memakai DOM palsu, jadi **tidak** menggantikan uji di browser sungguhan.
