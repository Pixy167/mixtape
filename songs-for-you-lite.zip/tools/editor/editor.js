'use strict';
/* Editor konten OFFLINE (tanpa server): ubah isi halaman lalu ekspor content/site.js.
   Draf tersimpan otomatis di localStorage browser ini (kunci "sfy-draft"); tombol Pratinjau membuka index.html?preview.
   HTML + CSS + JavaScript murni. Semua elemen dibuat lewat h() (textContent), jadi aman dari XSS. */
const $ = (s, r = document) => r.querySelector(s);
const h = (tag, props = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v; else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (['value', 'checked', 'disabled', 'hidden', 'multiple'].includes(k)) e[k] = v; else e.setAttribute(k, v);
  }
  for (const c of kids.flat()) e.append(c && c.nodeType ? c : document.createTextNode(c == null ? '' : c));
  return e;
};
const KEY = 'sfy-draft', ROOT = '../../';
const LOCAL = {}, PREV = {};                       // file yang dipilih sesi ini: path tujuan → File / object URL (hanya untuk pratinjau di editor)
const clone = o => JSON.parse(JSON.stringify(o));
const url = p => PREV[p] || (/^(https?:|blob:|data:)/.test(p) ? p : ROOT + p);
const pickLocal = (file, dir) => { const path = dir + file.name.replace(/[^\w.\-]+/g, '-').replace(/^-+/, ''); LOCAL[path] = file; PREV[path] = URL.createObjectURL(file); return { url: path }; };

let S, tab = 0;
const mark = () => { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch {} $('#bar').classList.add('dirty'); $('#msg').textContent = 'Draf tersimpan di browser ini · belum diekspor ke site.js'; };
const setMsg = t => { $('#msg').textContent = t; $('#bar').classList.remove('dirty'); };
const btn = (t, fn, cls = 'sec') => h('button', { class: 'btn ' + cls, type: 'button', onclick: fn }, t);
const move = (a, i, d, redraw) => { const j = i + d; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; mark(); redraw(); };
const field = (label, obj, key, o = {}) => {
  const el = o.area ? h('textarea', { rows: o.rows || 3, value: obj[key] || '' }) : h('input', { type: o.type || 'text', value: obj[key] == null ? '' : obj[key] });
  el.addEventListener('input', () => { obj[key] = o.type === 'number' ? +el.value : el.value; mark(); o.after && o.after(); });
  return h('label', {}, label, el);
};
const range = (label, obj, key, lo, hi, step, after) => {
  const out = h('b', {}, obj[key]), el = h('input', { type: 'range', min: lo, max: hi, step, value: obj[key] });
  el.addEventListener('input', () => { obj[key] = +el.value; out.textContent = el.value; mark(); after && after(); });
  return h('label', {}, h('span', {}, label + ': ', out), el);
};
const row2 = (...c) => h('div', { class: 'row2' }, c);
const picker = (text, accept, cb, multi, dir) => {
  const st = h('small', { class: 'st' });
  const inp = h('input', { type: 'file', accept, hidden: true, multiple: !!multi, onchange: async e => {
    for (const f of [...e.target.files]) { try { const d = pickLocal(f, dir); st.textContent = '✓ ' + d.url; await cb(d, f); mark(); } catch (err) { st.textContent = '✗ ' + err.message; } }
    e.target.value = '';
  } });
  return h('span', { class: 'pick' }, h('label', { class: 'btn sec', style: 'margin:0' }, text, inp), st);
};
const preview = (src, kind) => !src ? '' : h(kind === 'video' ? 'video' : 'audio', { controls: '', preload: 'none', src: url(src) });
const urlField = (label, obj, key, accept, kind, redraw) => h('div', {}, field(label + ' — path file', obj, key, { after: redraw }),
  h('div', { class: 'ctl' }, picker('Pilih file…', accept, d => { obj[key] = d.url; redraw(); }, false, 'media/'), obj[key] ? btn('Kosongkan', () => { obj[key] = ''; mark(); redraw(); }, 'danger') : ''), preview(obj[key], kind));
const list = build => { const box = h('div'); const draw = () => box.replaceChildren(...build(draw)); draw(); return box; };
const dur = src => new Promise(ok => { const a = new Audio(); a.preload = 'metadata'; a.onloadedmetadata = () => ok(Math.round(a.duration) || 0); a.onerror = () => ok(0); a.src = url(src); });

// ---- ekspor ----
const slug = s => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
const norm = () => {
  const o = clone(S); o.note.paragraphs = o.note.paragraphs.map(p => String(p).trim()).filter(Boolean);
  for (const k of ['tracks', 'photos', 'bouquets']) { const out = []; o[k].forEach((it, i) => { let base = slug(it.id || it.title) || k[0] + (i + 1), x = base, n = 2; while (out.some(q => q.id === x)) x = `${base}-${n++}`; it.id = x; out.push(it); }); }
  o.photos.forEach(p => { p.rotate = +p.rotate || 0; p.focus = Math.round(+p.focus); if (!(p.focus >= 0)) p.focus = 40; }); o.voice.duration = Math.round(+o.voice.duration || 0); return o;
};
const toJs = () => '/* Isi halaman. Edit langsung di sini, atau pakai tools/editor/index.html lalu timpa file ini dengan hasil ekspornya.\n   Path file (audio, video, foto, buket) relatif terhadap folder proyek ini. */\nwindow.SITE = ' + JSON.stringify(norm(), null, 2) + ';\n';
const exportFile = () => { const a = h('a', { href: URL.createObjectURL(new Blob([toJs()], { type: 'text/javascript' })), download: 'site.js' }); document.body.append(a); a.click(); a.remove(); setMsg('site.js diunduh ✓ — timpa file content/site.js di proyek, lalu deploy ulang'); };
const copyJson = () => navigator.clipboard.writeText(toJs()).then(() => setMsg('Disalin ✓'), () => setMsg('Tidak bisa menyalin — pakai Unduh'));
const discard = () => { if (!confirm('Buang draf dan mulai lagi dari content/site.js?')) return; try { localStorage.removeItem(KEY); } catch {} S = ensure(clone(window.SITE)); show(); setMsg('Draf dibuang'); };

const PANES = [
  ['Umum', () => [
    row2(field('Untuk (penerima)', S, 'to'), field('Dari (pengirim)', S, 'from')), field('Judul halaman', S, 'title'),
    row2(field('Label tombol “Finish”', S, 'finishLabel'), field('Judul kartu foto', S, 'polaroidsTitle')),
    row2(field('Judul kartu buket', S, 'bouquetTitle'), field('Subjudul buket', S, 'bouquetSub')), field('Teks bantuan (tombol Help)', S, 'help', { area: 1 })]],
  ['Catatan & surat', () => [h('h3', {}, 'Catatan (liner note)'), field('Label', S.note, 'label'),
    list(redraw => [...S.note.paragraphs.map((p, i) => h('div', { class: 'item' }, h('textarea', { rows: 4, value: p, oninput: e => { S.note.paragraphs[i] = e.target.value; mark(); } }),
      h('div', { class: 'ctl' }, btn('↑', () => move(S.note.paragraphs, i, -1, redraw)), btn('↓', () => move(S.note.paragraphs, i, 1, redraw)), btn('Hapus', () => { S.note.paragraphs.splice(i, 1); mark(); redraw(); }, 'danger')))),
      btn('+ Tambah paragraf', () => { S.note.paragraphs.push(''); mark(); redraw(); })]),
    h('h3', {}, 'Surat (kartu “Letter”)'), row2(field('Label', S.letter, 'label'), field('Judul', S.letter, 'title')), field('Subjudul', S.letter, 'subtitle'), field('Dari', S.letter, 'from')]],
  ['Voice note', () => [row2(field('Judul', S.voice, 'title'), field('Petunjuk', S.voice, 'hint')),
    list(redraw => [urlField('File audio (m4a/mp3)', S.voice, 'src', 'audio/*', 'audio', redraw),
      h('div', { class: 'ctl' }, picker('Pilih rekaman baru…', 'audio/*', async d => { S.voice.src = d.url; S.voice.duration = await dur(d.url); redraw(); }, false, 'media/'))]),
    field('Durasi (detik)', S.voice, 'duration', { type: 'number' }), h('p', { class: 'hint' }, 'Kosongkan path audio untuk menyembunyikan kartu voice note.')]],
  ['Lagu', () => [list(redraw => [...S.tracks.map((t, i) => h('div', { class: 'item' }, h('b', {}, `Lagu ${i + 1}`),
      row2(field('Judul', t, 'title'), field('Artis', t, 'artist')),
      urlField('Audio (mp3/m4a)', t, 'audio', 'audio/*', 'audio', redraw), urlField('Video (mp4, opsional)', t, 'video', 'video/*', 'video', redraw),
      h('div', { class: 'ctl' }, btn('↑', () => move(S.tracks, i, -1, redraw)), btn('↓', () => move(S.tracks, i, 1, redraw)), btn('Hapus lagu', () => { if (confirm('Hapus lagu ini?')) { S.tracks.splice(i, 1); mark(); redraw(); } }, 'danger')))),
      btn('+ Tambah lagu', () => { S.tracks.push({ id: '', title: 'Lagu baru', artist: '', audio: '', video: '' }); mark(); redraw(); })])]],
  ['Foto', () => [h('p', { class: 'hint' }, 'Foto dibingkai polaroid otomatis. Geser “posisi vertikal” supaya wajah pas. File foto baru harus disalin ke folder assets/photos/ (lihat tab Ekspor).'),
    list(redraw => [...S.photos.map((p, i) => { const pv = h('div', { class: 'pv' }); const setPv = () => { pv.style.backgroundImage = `url(${JSON.stringify(url(p.src))})`; pv.style.backgroundPosition = `50% ${p.focus}%`; pv.style.transform = `rotate(${p.rotate}deg)`; }; setPv();
      return h('div', { class: 'item photo' }, pv, h('div', {}, field('Caption', p, 'caption'), field('Path foto', p, 'src', { after: setPv }), range('Kemiringan (°)', p, 'rotate', -10, 10, 0.5, setPv), range('Posisi vertikal foto (%)', p, 'focus', 0, 100, 1, setPv),
        h('div', { class: 'ctl' }, picker('Ganti foto…', 'image/*', d => { p.src = d.url; redraw(); }, false, 'assets/photos/'), btn('↑', () => move(S.photos, i, -1, redraw)), btn('↓', () => move(S.photos, i, 1, redraw)), btn('Hapus', () => { S.photos.splice(i, 1); mark(); redraw(); }, 'danger')))); }),
      picker('+ Tambah foto…', 'image/*', d => { S.photos.push({ id: '', src: d.url, caption: S.to, rotate: S.photos.length % 2 ? 2.5 : -3, focus: 40 }); redraw(); }, true, 'assets/photos/')])]],
  ['Buket', () => [h('p', { class: 'hint' }, 'Pakai gambar PNG/WebP dengan latar transparan (maks. 8). File baru disalin ke folder assets/.'),
    list(redraw => [...S.bouquets.map((b, i) => h('div', { class: 'item' }, h('div', { class: 'bqv', style: `background-image:url(${JSON.stringify(url(b.src))})` }), field('Path gambar', b, 'src', { after: () => {} }),
      h('div', { class: 'ctl' }, picker('Ganti gambar…', 'image/*', d => { b.src = d.url; redraw(); }, false, 'assets/'), btn('↑', () => move(S.bouquets, i, -1, redraw)), btn('↓', () => move(S.bouquets, i, 1, redraw)), btn('Hapus', () => { S.bouquets.splice(i, 1); mark(); redraw(); }, 'danger')))),
      picker('+ Tambah buket…', 'image/*', d => { S.bouquets.push({ id: '', src: d.url }); redraw(); }, true, 'assets/')])]],
  ['Ekspor', () => [h('p', { class: 'hint' }, 'Perubahan otomatis tersimpan sebagai draf di browser ini. Cara memasangnya ke website:'),
    h('ol', {}, h('li', {}, 'Klik “Unduh site.js”, lalu timpa file content/site.js di proyek.'), h('li', {}, 'Salin file media/foto baru ke folder yang tertera di tabel bawah.'), h('li', {}, 'Deploy ulang (git push, atau vercel --prod).')),
    h('div', { class: 'ctl' }, btn('Unduh site.js', exportFile, ''), btn('Salin isi file', copyJson), btn('Pratinjau', () => window.open(ROOT + 'index.html?preview', '_blank'))),
    h('h3', {}, 'File baru yang harus disalin (sesi ini)'),
    Object.keys(LOCAL).length ? h('table', {}, Object.entries(LOCAL).map(([p, f]) => h('tr', {}, h('td', {}, f.name), h('td', { class: 'mut' }, (f.size / 1048576).toFixed(2) + ' MB'), h('td', {}, 'salin ke ', h('code', {}, p))))) : h('p', { class: 'mut' }, 'Belum ada file yang dipilih di sesi ini.'),
    h('h3', {}, 'Lanjutan'), btn('Buang draf & mulai dari content/site.js', discard, 'danger')]],
];
function show() {
  $('#tabs').replaceChildren(...PANES.map(([n], i) => h('button', { role: 'tab', 'aria-selected': i === tab, onclick: () => { tab = i; show(); } }, n)));
  $('#pane').replaceChildren(...PANES[tab][1]());
}
const ensure = o => { o.note = o.note || { label: '', paragraphs: [] }; o.note.paragraphs = o.note.paragraphs || []; o.letter = o.letter || {}; o.voice = o.voice || {}; for (const k of ['tracks', 'photos', 'bouquets']) o[k] = o[k] || []; return o; };
$('#save').onclick = exportFile; $('#prev').onclick = () => window.open(ROOT + 'index.html?preview', '_blank');
if (!window.SITE) { $('#pane').textContent = 'content/site.js tidak ditemukan. Buka editor ini dari folder proyek (tools/editor/index.html).'; }
else {
  let draft = null; try { draft = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch {}
  S = ensure(draft || clone(window.SITE)); show(); setMsg(draft ? 'Draf dipulihkan dari browser ini' : 'Siap — edit lalu klik “Unduh site.js”');
}
