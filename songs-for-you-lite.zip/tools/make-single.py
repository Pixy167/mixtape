#!/usr/bin/env python3
"""Bangun SATU file index.html (CSS, JS, isi, gambar, audio, video semuanya ter-embed) dari proyek ini.
   Cocok untuk upload dari HP: GitHub web membatasi 25 MB per file dan tidak bisa upload folder dari HP.
   Pakai:  python3 tools/make-single.py      → hasil: dist/index.html   (ukuran ±20 MB untuk isi bawaan)"""
import re, base64, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rd = lambda p: open(os.path.join(ROOT, p), encoding='utf-8').read()
html, css, app, site = rd('index.html'), rd('css/style.css'), rd('js/app.js'), rd('content/site.js')
MIME = {'.webp': 'image/webp', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif',
        '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.mp4': 'video/mp4', '.webm': 'video/webm'}
IMG = ('.webp', '.jpg', '.jpeg', '.png', '.gif')
PAT = re.compile(r'(?<![\w/.])((?:assets|media)/[\w\-./]+\.(?:webp|jpg|jpeg|png|gif|mp3|m4a|mp4|webm))')
b64 = lambda p: base64.b64encode(open(os.path.join(ROOT, p), 'rb').read()).decode()
uri = lambda p: f'data:{MIME[os.path.splitext(p)[1]]};base64,{b64(p)}'
refs = sorted(set(PAT.findall(html + css + app + site)))
missing = [r for r in refs if not os.path.exists(os.path.join(ROOT, r))]
if missing: sys.exit('File dirujuk tapi tidak ada: ' + ', '.join(missing))
# 1) gambar yang tertulis langsung di HTML/CSS → data-URI inline
inline = set()
def sub_src(m): inline.add(m.group(2)); return m.group(1) + uri(m.group(2)) + m.group(3)
html = re.sub(r'(src=")(assets/[\w\-./]+)(")', sub_src, html)
css = re.sub(r'(url\(["\']?)(assets/[\w\-./]+)(["\']?\))', sub_src, css)
# 2) gambar yang dirujuk dari site.js/app.js → peta path→data-URI; audio/video → blok base64 yang di-decode bertahap
imgs = {p: uri(p) for p in refs if p.endswith(IMG) and p not in inline}
media = [p for p in refs if not p.endswith(IMG)]
esc = lambda s: s.replace('</', '<\\/')
helper = r'''(function(){
// Tap amplop yang terjadi sebelum seluruh dokumen (termasuk blok lagu di bagian bawah) selesai diunduh DIANTRE diam-diam
// lalu dijalankan begitu siap — supaya lagu tidak gagal ter-load di koneksi lambat, tanpa tulisan "Loading…".
(()=>{if(document.readyState!=='loading')return;let ready=false,pend=false;
  const hit=e=>{const t=e.target&&e.target.closest&&e.target.closest('#env');if(!ready&&t){e.stopPropagation();e.preventDefault();pend=true}};
  addEventListener('click',hit,true);addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')hit(e)},true);
  document.addEventListener('DOMContentLoaded',()=>{ready=true;removeEventListener('click',hit,true);if(pend){const e=document.getElementById('env');if(e)e.click()}})})();
const D=%s;
const MD={};
const mdstep=(p,budget)=>{
  const el=document.querySelector('script[data-media="'+p+'"]');if(!el)return null;
  let d=MD[p];if(!d)d=MD[p]={s:el.textContent.trim(),i:0,parts:[],url:''};
  while(!d.url&&budget>0){
    const CH=1<<20,b=atob(d.s.slice(d.i,d.i+CH)),u=new Uint8Array(b.length);
    for(let j=0;j<b.length;j++)u[j]=b.charCodeAt(j);
    d.parts.push(u);d.i+=CH;budget-=CH;
    if(d.i>=d.s.length){d.url=URL.createObjectURL(new Blob(d.parts,{type:el.dataset.type}));d.s='';d.parts=null;el.textContent=''}}
  return d};
window.__U=p=>{if(D[p])return D[p];const d=mdstep(p,Infinity);return d?d.url:p};
addEventListener('load',()=>{const q=[...document.querySelectorAll('script[data-media]')].map(e=>e.dataset.media).sort((a,b)=>/[.](mp3|m4a)$/.test(b)-/[.](mp3|m4a)$/.test(a));
  const tick=()=>{while(q.length&&MD[q[0]]&&MD[q[0]].url)q.shift();if(!q.length)return;mdstep(q[0],1<<20);setTimeout(tick,60)};setTimeout(tick,1200)});
})();''' % __import__('json').dumps(imgs)
# 3) rakit: CSS & JS inline, blok media di paling bawah (setelah script utama → halaman interaktif duluan)
html = html.replace('<link rel="stylesheet" href="css/style.css">', '<style>\n' + css.strip() + '\n</style>')
for src, code in (('content/site.js', site), ('js/app.js', app)):
    tag = f'<script src="{src}"></script>'
    assert html.count(tag) == 1, 'tag tidak ditemukan: ' + tag
    html = html.replace(tag, '<script>\n' + esc(code.strip()) + '\n</script>' + ('\n<script>\n' + esc(helper) + '\n</script>' if src == 'content/site.js' else ''))
blocks = ''.join(f'<script type="text/plain" data-media="{p}" data-type="{MIME[os.path.splitext(p)[1]]}">{b64(p)}</script>\n' for p in media)
html = html.replace('</body>', '<!-- media ter-embed (base64) -->\n' + blocks + '</body>')
os.makedirs(os.path.join(ROOT, 'dist'), exist_ok=True)
out = os.path.join(ROOT, 'dist', 'index.html'); open(out, 'w', encoding='utf-8').write(html)
mb = os.path.getsize(out) / 1e6
print(f'dist/index.html: {mb:.1f} MB | gambar inline: {len(inline)}, peta: {len(imgs)}, media: {len(media)}')
if mb > 24: print('PERINGATAN: lebih dari 24 MB — GitHub web menolak file > 25 MB. Kecilkan media dulu.')
